/*
 * astar_MapConfirm.c
 *
 *  Created on: Sep 2, 2015
 *      Author: jacky
 */

/*
 * usage:
 * InitRoadLines();
 * while(Run line of Robot)
 * {
 *        RoadLine* RLPtr = RoadLineMalloc();
 *        if(RLPtr)
 *        {
 *         set value of RLPtr;
 *         RoadLinePush(RLPtr);
 *     }
 *     else
 *     {
 *         if(FindExceptionPoint())
 *         {
 *             all exception point be in the exceptionpiont stack
 *         }
 *         else
 *         {
 *             error
 *             no RoadLine in RoadLineStack
 *         }
 *     }
 * }
 */
#include <math.h>
#include <string.h>
#include "astar_MapConfirm.h"
#include "astar_algorithm.h"
#include "MapDealer.h"
#include <stack>
//unsigned char

unsigned char * StartAddressofFix;
RoadLine RoadLines[MaxRoadLines];
RoadLine* RoadLineStack;
RoadLine* RoadLineStackHeadPtr;
unsigned char RoadLinefortag;

stack<MapRoadLineGrid>  RoadLineGrid;

/*
 * 初始化RoadLines内存空间，以备进行分配与回收
 */
unsigned char InitRoadLines(void)
{
    for(RoadLinefortag = 0; RoadLinefortag < MaxRoadLines; RoadLinefortag++)
    {
        RoadLines[RoadLinefortag].startx = 0;
        RoadLines[RoadLinefortag].starty = 0;
        RoadLines[RoadLinefortag].endx = 0;
        RoadLines[RoadLinefortag].endy = 0;
        RoadLines[RoadLinefortag].RoadAnalysis = 0x00;
        RoadLines[RoadLinefortag].next = NULL;
        RoadLines[RoadLinefortag].parent = NULL;
        RoadLines[RoadLinefortag].Valid = 1;
        RoadLines[RoadLinefortag].owntag = RoadLinefortag;
    }
    RoadLineStack = NULL;
    RoadLineStackHeadPtr = NULL;
    if(MaxRoadLines == RoadLinefortag)
        return 1;
    else
        return 0;
}

/*
 * 从RoadLines空间中分配一个可用的单元
 */
RoadLine* RoadLineMalloc()
{
    for(RoadLinefortag = 0; RoadLinefortag < MaxRoadLines; RoadLinefortag++)
    {
        if(1 == RoadLines[RoadLinefortag].Valid)
        {
            RoadLines[RoadLinefortag].Valid = 0;
            RoadLines[RoadLinefortag].startx = 0;
            RoadLines[RoadLinefortag].starty = 0;
            RoadLines[RoadLinefortag].endx = 0;
            RoadLines[RoadLinefortag].endy = 0;
            RoadLines[RoadLinefortag].RoadAnalysis = 0x00;
            RoadLines[RoadLinefortag].next = NULL;
            RoadLines[RoadLinefortag].parent = NULL;
            return &RoadLines[RoadLinefortag];
        }
    }
    return NULL;
}

/*
 * 释放一个RoadLine单元
 */
void RoadLineFree(RoadLine* RoadLinePtr)
{
    RoadLinePtr->Valid = 1;
    RoadLinePtr->startx = 0;
    RoadLinePtr->starty = 0;
    RoadLinePtr->endx = 0;
    RoadLinePtr->endy = 0;
    RoadLinePtr->RoadAnalysis = 0x00;
    RoadLinePtr->next = NULL;
    RoadLinePtr->parent = NULL;
    return;
}

/*
 * 判断单条路径中是否存在漂移的情况，如果存在分成两条路径入库
 */
void CheckDriftInRoad(void* lparam,RoadLine* InRoadLinePtr, unsigned char* endy1, unsigned char* endy2)
{
    MapDealer * pMapDealer;
    pMapDealer = (MapDealer*) lparam;

    unsigned char sx = InRoadLinePtr->startx;
    unsigned char sy = InRoadLinePtr->starty;
    //unsigned char ex = InRoadLinePtr->endx;
    unsigned char ey = InRoadLinePtr->endy;
    int8_t tag = CreateIncrement(ey, sy);
    int8_t increment = 0;
    unsigned char ss;
    unsigned char circles = 0;

    *endy1 = 255;
    *endy2 = 255;

    switch(tag)
    {
    case 1:
        //正向增长
        increment = 1;
        for(ss=sy; ss <= ey; ss+=increment)
        {
            if(0 == pMapDealer->Fix[sx][ss])
            {
                if(0 == circles)
                {
                    *endy1 = ss-1;
                    circles = 1;
                }
            }
            else
            {
                if(0 != circles)
                {
                    *endy2 = ss;
                    circles = 0;
                }
            }
        }
        break;
    case -1:
        //逆向增长
        increment = -1;
        for(ss=sy; ss >= ey; ss+=increment)
        {
            if(0 == pMapDealer->Fix[sx][ss])
            {
                if(0 == circles)
                {
                    *endy1 = ss+1;
                    circles = 1;
                }
            }
            else
            {
                if(0 != circles)
                {
                    *endy2 = ss;
                    circles = 0;
                }
            }
        }
        break;
    default:
        break;
    }
    return;
}

/*
 * RoadLine单元入栈
 */
unsigned char RoadLinePush(void* lparam,RoadLine* InRoadLinePtr)
{
    MapDealer * pMapDealer;
    pMapDealer = (MapDealer*) lparam;
    unsigned char ey1;
    unsigned char ey2;
    RoadLine* RLPtr;

    if(!InRoadLinePtr)
    {
        return 0;
    }

    if(!RoadLineStack)
    {
        CheckDriftInRoad(pMapDealer,InRoadLinePtr, &ey1, &ey2);

        if(255 != ey2)
        {
            InRoadLinePtr->endy = ey1;
            RoadLineStack = InRoadLinePtr;
            RoadLineStackHeadPtr = RoadLineStack;

            RLPtr = RoadLineMalloc();
            if(RLPtr)
            {
                RLPtr->startx = InRoadLinePtr->startx;
                RLPtr->starty = ey2;
                RLPtr->endx = RLPtr->startx;
                RLPtr->endy = InRoadLinePtr->endy;

                RoadLineStack->next = RLPtr;
                RLPtr->parent = RoadLineStack;
                RoadLineStack = RLPtr;
            }
        }
        else
        {
            RoadLineStack = InRoadLinePtr;
            RoadLineStackHeadPtr = RoadLineStack;
        }
    }
    else
    {
        CheckDriftInRoad(pMapDealer,InRoadLinePtr, &ey1, &ey2);

        if(255 != ey2)
        {
            InRoadLinePtr->endy = ey1;
            RoadLineStack->next = InRoadLinePtr;
            InRoadLinePtr->parent = RoadLineStack;
            RoadLineStack = InRoadLinePtr;

            RLPtr = RoadLineMalloc();      /////////////////////////20150922
            if(RLPtr)
            {
                RLPtr->startx = InRoadLinePtr->startx;
                RLPtr->starty = ey2;
                RLPtr->endx = RLPtr->startx;
                RLPtr->endy = InRoadLinePtr->endy;

                RoadLineStack->next = RLPtr;
                RLPtr->parent = RoadLineStack;
                RoadLineStack = RLPtr;
            }
        }
        else
        {
            RoadLineStack->next = InRoadLinePtr;
            InRoadLinePtr->parent = RoadLineStack;
            RoadLineStack = InRoadLinePtr;
        }
    }
    return 1;
}

/*
 * RoadLine单元出栈
 */
unsigned char RoadLinePop(RoadLine* OutRoadLinePtr)
{
    RoadLine* tmp;
    if(!RoadLineStackHeadPtr)
    {
        return 0;
    }
    else
    {
    /*
         //先进后出
        OutRoadLinePtr->startaddress = RoadLineStack->startaddress;
        OutRoadLinePtr->endaddress = RoadLineStack->endaddress;
        OutRoadLinePtr->RoadAnalysis = RoadLineStack->RoadAnalysis;
        OutRoadLinePtr->next = RoadLineStack->next;
        OutRoadLinePtr->parent = RoadLineStack->parent;
        OutRoadLinePtr->owntag = RoadLineStack->owntag;
        OutRoadLinePtr->Valid = RoadLineStack->Valid;
        RoadLine* tmp = RoadLineStack;
        RoadLineStack = RoadLineStack->parent;
        RoadLineFree(tmp);
    */
        //先进先出
        OutRoadLinePtr->startx = RoadLineStackHeadPtr->startx;
        OutRoadLinePtr->starty = RoadLineStackHeadPtr->starty;
        OutRoadLinePtr->endx = RoadLineStackHeadPtr->endx;
        OutRoadLinePtr->endy = RoadLineStackHeadPtr->endy;
        OutRoadLinePtr->RoadAnalysis = RoadLineStackHeadPtr->RoadAnalysis;
        OutRoadLinePtr->next = RoadLineStackHeadPtr->next;
        OutRoadLinePtr->parent = RoadLineStackHeadPtr->parent;
        OutRoadLinePtr->owntag = RoadLineStackHeadPtr->owntag;
        OutRoadLinePtr->Valid = RoadLineStackHeadPtr->Valid;
        tmp = RoadLineStackHeadPtr;
        RoadLineStackHeadPtr = RoadLineStackHeadPtr->next;
        if(!RoadLineStackHeadPtr)
            RoadLineStack = NULL;
        RoadLineFree(tmp);
    }
    return 1;
}

/*
 * 获取RoadLine栈顶单元
 */
unsigned char RoadLineTop(RoadLine* TopRoadLinePtr)
{
    if(!RoadLineStack)
    {
        return 0;
    }
    else
    {
        TopRoadLinePtr->startx = RoadLineStack->startx;
        TopRoadLinePtr->starty = RoadLineStack->starty;
        TopRoadLinePtr->endx = RoadLineStack->endx;
        TopRoadLinePtr->endy = RoadLineStack->endy;
        TopRoadLinePtr->RoadAnalysis = RoadLineStack->RoadAnalysis;
        TopRoadLinePtr->next = RoadLineStack->next;
        TopRoadLinePtr->parent = RoadLineStack->parent;
        TopRoadLinePtr->owntag = RoadLineStack->owntag;
        TopRoadLinePtr->Valid = RoadLineStack->Valid;
    }
    return 1;
}

/*
 * 确定RoadLine增长方向
 */
int8_t CreateIncrement(unsigned char End, unsigned char Start)
{

    if ((End - Start) > 0)
    {
        return 1;
    }
    else if ((End - Start) < 0)
    {
        return -1;
    }
    else
    {
        return 0;
    }
}

/*
 * 判断路径的封闭性
 */
unsigned char CheckClosure(void* lparam,unsigned char End, unsigned char Start, unsigned char Xindex)
{
    MapDealer * pMapDealer;
    pMapDealer = (MapDealer*) lparam;
    MapRoadLineGrid TempGrid;

    int8_t increment;
    int8_t tmpfortag;
    //new start
    unsigned char tmpnode1;
    unsigned char tmpnode2;
    int16_t substart = 255;
    int16_t subend = 255;
    int8_t subtag = 0;
    int8_t IsCircle = 1;
    int8_t left = 0;
    int8_t right = 0;
    //new end
    
    
    increment = CreateIncrement(End, Start);

    //端点均是可达点
    if(!increment)
    {
        //起点与终点重合
        if((pMapDealer->Fix[Xindex-1][Start]!=0)&&(pMapDealer->Fix[Xindex+1][Start]!=0)
         &&(pMapDealer->Fix[Xindex][Start+1]!=0)&&(pMapDealer->Fix[Xindex][Start-1]!=0))
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    else if(1 == increment)
    {
        //起点与终点不重合，且为增长，起点与终点差值大于-1
	    //new start
		substart = 255;
		subend = 255;
		subtag = 0;
		IsCircle = 1;
		left = 0;
		right = 0;
		while(IsCircle)
		{
			for(tmpfortag = subtag; tmpfortag<=End-Start; tmpfortag+=increment,subtag+=increment)
			{
				tmpnode1 = pMapDealer->Fix[Xindex-1][Start+tmpfortag];
				tmpnode2 = pMapDealer->Fix[Xindex+1][Start+tmpfortag];
				if(0 == tmpnode1)
				{
					substart = tmpfortag;
					left = 1;
					break;
				}
				if(0 == tmpnode2)
				{
					substart = tmpfortag;
					right = 1;
					break;
				}
				
			}
			if(255 == substart)
			{
				IsCircle = 0;
			}
			else
			{
				if(subtag < End-Start)
				{
					subtag+=increment;
					for(tmpfortag = subtag; tmpfortag<=End-Start; tmpfortag+=increment,subtag+=increment)
					{
						tmpnode1 = pMapDealer->Fix[Xindex-1][Start+tmpfortag];
						tmpnode2 = pMapDealer->Fix[Xindex+1][Start+tmpfortag];
						if((0 == tmpnode1)||(0 == tmpnode2))
						{
							if(left&&(0 != tmpnode1))
							{
								subend = tmpfortag;
                                TempGrid.x = Xindex;
                                TempGrid.y = Start+substart;
                                RoadLineGrid.push(TempGrid);
                                pMapDealer->Fix[Xindex][Start+substart]|=EXCEP;
                                #ifdef TEST_USART_Debug_MAP
                                //vUsart3_Send_Map(Xindex,Start+substart,pMapDealer->Fix[Xindex][Start+substart]);
                                #endif
                                TempGrid.y = Start+subend;
                                RoadLineGrid.push(TempGrid);
                                pMapDealer->Fix[Xindex][Start+subend]|=EXCEP;
                                #ifdef TEST_USART_Debug_MAP
                                //vUsart3_Send_Map(Xindex,Start+subend,pMapDealer->Fix[Xindex][Start+subend]);
                                #endif
                                
								break;
							}
							
							if(right&&(0 != tmpnode2))
							{
								subend = tmpfortag;
                                TempGrid.x = Xindex;
                                TempGrid.y = Start+substart;
                                RoadLineGrid.push(TempGrid);
                                pMapDealer->Fix[Xindex][Start+substart]|=EXCEP;
                                #ifdef TEST_USART_Debug_MAP
                                //vUsart3_Send_Map(Xindex,Start+substart,pMapDealer->Fix[Xindex][Start+substart]);
                                #endif
                                TempGrid.y = Start+subend;
                                RoadLineGrid.push(TempGrid);
                                pMapDealer->Fix[Xindex][Start+subend]|=EXCEP;
                                #ifdef TEST_USART_Debug_MAP
                                //vUsart3_Send_Map(Xindex,Start+subend,pMapDealer->Fix[Xindex][Start+subend]);
                                #endif
                                
								break;
							}
						}
						else
						{
						    //subend = tmpfortag;
							subend = tmpfortag - increment;
							subtag -= increment;
                            TempGrid.x = Xindex;
                            TempGrid.y = Start+substart;
                            RoadLineGrid.push(TempGrid);
                            pMapDealer->Fix[Xindex][Start+substart]|=EXCEP;
                            #ifdef TEST_USART_Debug_MAP
                            //vUsart3_Send_Map(Xindex,Start+substart,pMapDealer->Fix[Xindex][Start+substart]);
                            #endif
                            TempGrid.y = Start+subend;
                            RoadLineGrid.push(TempGrid);
                            pMapDealer->Fix[Xindex][Start+subend]|=EXCEP;
                            #ifdef TEST_USART_Debug_MAP
                            //vUsart3_Send_Map(Xindex,Start+subend,pMapDealer->Fix[Xindex][Start+subend]);
                            #endif

							break;
						}
					}
					if((subend == (End-Start))||(255 == subend))
					{
						IsCircle = 0;
					}
					subtag+=increment;
					left = 0;
					right = 0;
				}
				else
				{
					IsCircle = 0;
				}
			}
		}

	//new end
        for(tmpfortag = 0; tmpfortag<=(End-Start); tmpfortag+=increment)
        {
            if(0 == tmpfortag)
            {
                if((pMapDealer->Fix[Xindex-1][Start]==0)||(pMapDealer->Fix[Xindex+1][Start]==0)
                 ||(pMapDealer->Fix[Xindex][Start-1]==0))
                {
                    return 0;
                }
            }
            if((End-Start) == tmpfortag)
            {
                if((pMapDealer->Fix[Xindex-1][End]==0)||(pMapDealer->Fix[Xindex+1][End]==0)
                 ||(pMapDealer->Fix[Xindex][End+1]==0))
                {
                    return 0;
                }
            }
            if((0 == pMapDealer->Fix[Xindex-1][Start+tmpfortag])
             ||(0 == pMapDealer->Fix[Xindex+1][Start+tmpfortag]))
            {
                return 0;
            }
        }
        return 1;
    }
    else if(-1 == increment)
    {
        //起点与终点不重合，且为减少，起点与终点差值小于-1
	//new start
		substart = 255;
		subend = 255;
		subtag = 0;
		IsCircle = 1;
		left = 0;
		right = 0;
		while(IsCircle)
		{
			for(tmpfortag = subtag; tmpfortag>=End-Start; tmpfortag+=increment,subtag+=increment)
			{
				tmpnode1 = pMapDealer->Fix[Xindex-1][Start+tmpfortag];
				tmpnode2 = pMapDealer->Fix[Xindex+1][Start+tmpfortag];
				if(0 == tmpnode1)
				{
					substart = tmpfortag;
					left = 1;
					break;
				}
				if(0 == tmpnode2)
				{
					substart = tmpfortag;
					right = 1;
					break;
				}
				
			}
			if(255 == substart)
			{
				IsCircle = 0;
			}
			else
			{
				if(subtag > End-Start)
				{
					subtag+=increment;
					for(tmpfortag = subtag; tmpfortag>=End-Start; tmpfortag+=increment,subtag+=increment)
					{
						tmpnode1 = pMapDealer->Fix[Xindex-1][Start+tmpfortag];
						tmpnode2 = pMapDealer->Fix[Xindex+1][Start+tmpfortag];
						if((0 == tmpnode1)||(0 == tmpnode2))
						{
							if(left&&(0 != tmpnode1))
							{
								subend = tmpfortag;

                                TempGrid.x = Xindex;
                                TempGrid.y = Start+substart;
                                RoadLineGrid.push(TempGrid);
                                pMapDealer->Fix[Xindex][Start+substart]|=EXCEP;
                                #ifdef TEST_USART_Debug_MAP
                                //vUsart3_Send_Map(Xindex,Start+substart,pMapDealer->Fix[Xindex][Start+substart]);
                                #endif
                                TempGrid.x = Xindex;
                                TempGrid.y = Start+subend;
                                RoadLineGrid.push(TempGrid);

                                pMapDealer->Fix[Xindex][Start+subend]|=EXCEP;
                                #ifdef TEST_USART_Debug_MAP
                                //vUsart3_Send_Map(Xindex,Start+subend,pMapDealer->Fix[Xindex][Start+subend]);
                                #endif
                                //vUsart3_Send_String(Xindex,Start+subend,'$','4','4');
								break;
							}
							
							if(right&&(0 != tmpnode2))
							{
								subend = tmpfortag;

                                TempGrid.x = Xindex;
                                TempGrid.y = Start+substart;
                                RoadLineGrid.push(TempGrid);
                                pMapDealer->Fix[Xindex][Start+substart]|=EXCEP;
                                #ifdef TEST_USART_Debug_MAP
                                //vUsart3_Send_Map(Xindex,Start+substart,pMapDealer->Fix[Xindex][Start+substart]);
                                #endif
                                TempGrid.y = Start+subend;
                                RoadLineGrid.push(TempGrid);
                                pMapDealer->Fix[Xindex][Start+subend]|=EXCEP;
                                #ifdef TEST_USART_Debug_MAP
                                //vUsart3_Send_Map(Xindex,Start+subend,pMapDealer->Fix[Xindex][Start+subend]);
                                #endif
                                //vUsart3_Send_String(Xindex,Start+subend,'$','5','5');
								break;
							}
						}
						else
						{
							//subend = tmpfortag;
							subend = tmpfortag - increment;
							subtag -= increment;
                            TempGrid.x = Xindex;
                            TempGrid.y = Start+substart;
                            RoadLineGrid.push(TempGrid);
                            pMapDealer->Fix[Xindex][Start+substart]|=EXCEP;
                            #ifdef TEST_USART_Debug_MAP
                            //vUsart3_Send_Map(Xindex,Start+substart,pMapDealer->Fix[Xindex][Start+substart]);
                            #endif
                            TempGrid.x = Xindex;
                            TempGrid.y = Start+subend;
                            RoadLineGrid.push(TempGrid);
                            pMapDealer->Fix[Xindex][Start+subend]|=EXCEP;
                            #ifdef TEST_USART_Debug_MAP
                            //vUsart3_Send_Map(Xindex,Start+subend,pMapDealer->Fix[Xindex][Start+subend]);
                            #endif
                            //vUsart3_Send_String(Xindex,Start+subend,'$','6','6');
							break;
						}
					}
					if((subend == (End-Start))||(255 == subend))
					{
						IsCircle = 0;
					}
					subtag+=increment;
					left = 0;
					right = 0;
				}
				else
				{
					IsCircle = 0;
				}
			}
		}
	//new end

        for(tmpfortag = 0; tmpfortag>=(End-Start); tmpfortag+=increment)
        {
            if(0 == tmpfortag)
            {
                if((pMapDealer->Fix[Xindex-1][Start]==0)||(pMapDealer->Fix[Xindex+1][Start]==0)
                 ||(pMapDealer->Fix[Xindex][Start+1]==0))
                {
                    return 0;
                }
            }
            if((End-Start) == tmpfortag)
            {
                if((pMapDealer->Fix[Xindex-1][End]==0)||(pMapDealer->Fix[Xindex+1][End]==0)
                 ||(pMapDealer->Fix[Xindex][End-1]==0))
                {
                    return 0;
                }
            }
            if((0 == pMapDealer->Fix[Xindex-1][Start+tmpfortag])||(0 == pMapDealer->Fix[Xindex+1][Start+tmpfortag]))
            {
                return 0;
            }
        }
        return 1;
    }
    return 0;
}

/*
 * 查找异常点
 */
unsigned char FindExceptionPoint(void* lparam)
{
    MapDealer * pMapDealer;
    pMapDealer = (MapDealer*) lparam;
    MapRoadLineGrid TempGrid;

    unsigned char StartXindex,StartYindex,EndXindex,EndYindex;
    RoadLine RoadLineiterator;
    if(!RoadLineStack)
    {
        return 0;
    }
    
    while(RoadLinePop(&RoadLineiterator))
    {
        //对RoadLine栈中的所有元素进行排查
//        FindStartindexofRoadLine(RoadLineiterator.startaddress, &StartXindex, &StartYindex);
//        FindEndindexofRoadLine(RoadLineiterator.endaddress, &EndXindex, &EndYindex);
        StartXindex = RoadLineiterator.startx;
        StartYindex = RoadLineiterator.starty;
        EndXindex = RoadLineiterator.endx;
        EndYindex = RoadLineiterator.endy;
        //vUsart3_Send_Data(StartXindex,StartYindex,EndXindex,EndYindex,'r');
        if(!CheckClosure(pMapDealer,EndYindex, StartYindex, StartXindex))
        {
            //不封闭，对起点和终点进行压栈，先压起点，再压终点
            //if(((StartXindex != START_X)&&(StartYindex != START_Y))&&((pMapDealer->Fix[StartXindex][StartYindex]&0x01)  == 0x01))
            if((pMapDealer->Fix[StartXindex][StartYindex]&0x01) == 0x01)  //可达点才压栈
            {
                //if((Fix_Check(StartXindex,StartYindex) == 0)&&((pMapDealer->Fix[StartXindex][StartYindex]&EXCEP) == 0))
                if((pMapDealer->Fix[StartXindex][StartYindex]&EXCEP) == 0)
                {

                    TempGrid.x = StartXindex;
                    TempGrid.y = StartYindex;
                    RoadLineGrid.push(TempGrid);
                    pMapDealer->Fix[StartXindex][StartYindex]|=EXCEP;
                    #ifdef TEST_USART_Debug_MAP
                    //vUsart3_Send_Map(StartXindex,StartYindex,pMapDealer->Fix[StartXindex][StartYindex]);
                    #endif
                }
                //UartSendState=0xAA;
            }
            //if(((EndXindex != END_X)&&(EndYindex != END_Y))&&((pMapDealer->Fix[EndXindex][EndYindex]&0x01) == 0x01))
            if((pMapDealer->Fix[EndXindex][EndYindex]&0x01) == 0x01)    //可达点才压栈
            {
                //if((Fix_Check(EndXindex,EndYindex) == 0)&&((pMapDealer->Fix[EndXindex][EndYindex]&EXCEP) == 0))
                if((pMapDealer->Fix[EndXindex][EndYindex]&EXCEP) == 0)
                {
                    TempGrid.x = EndXindex;
                    TempGrid.y = EndYindex;
                    RoadLineGrid.push(TempGrid);
                    pMapDealer->Fix[EndXindex][EndYindex]|=EXCEP;
                    #ifdef TEST_USART_Debug_MAP
                    //vUsart3_Send_Map(EndXindex,EndYindex,pMapDealer->Fix[EndXindex][EndYindex]);
                    #endif
                }
               // UartSendState=0xAA;
            }
        }
        //RoadLinePop(&RoadLineiterator);
    }
    InitRoadLines();
    return 1;
}


int PushLineToStack(void* lparam, int endx,int endy,int startx,int starty)
{
    MapDealer * pMapDealer;
    pMapDealer = (MapDealer*) lparam;
    RoadLine* RLPtr = RoadLineMalloc();

    if(RLPtr)
    {
        //set value of RLPtr;
        RLPtr->endx = endx;
        RLPtr->endy = endy;
        RLPtr->startx = startx;
        RLPtr->starty = starty;
        RoadLinePush(lparam,RLPtr);
    }
    else
    {
        if(FindExceptionPoint(pMapDealer))
        {
            //all exception point be in the exceptionpiont stack
        }
        else
        {
            //error
            //no RoadLine in RoadLineStack
        }
    }

}








