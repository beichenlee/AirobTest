/*
 * CleanPlaner.h
 *
 *  Created on: Jan 17, 2019
 *      Author: Beichen Li
 */

#ifndef CLEANPLANER_H_  
#define CLEANPLANER_H_

#include <sys/types.h>
#include <pthread.h>
#include <sys/time.h>
#include <fcntl.h>
#include <errno.h>
#include <memory.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <stdio.h>
#include <queue>

//#include "main.h"
//#include "MapDealer.h"
#include "unit.h"
#include "astar_algorithm.h"



using namespace std;


class MainProgram;

class CleanPlaner
{
public:
    int BlockStartX;
    int BlockStartY;
public:
    CleanPlaner(void);
	virtual ~CleanPlaner(void);

    int open(MainProgram *lp);

	//void init();
    
    int CleanOneBlock(int x,int y);
    int isBlockClose(int x, int y);
    void SendMapOfOneGrid(int x,int y);
    void CleanUpdateMap(int x,int y,int value);
    void SendNineGrid(int x, int y);
   // int CleanAllRoom(void);

private:
    MainProgram* m_MainProgram;

};

#endif   /*CLEANPLANER_H_*/