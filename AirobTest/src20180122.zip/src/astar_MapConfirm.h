/*
 * astar_MapConfirm.h
 *
 *  Created on: Sep 2, 2015
 *      Author: jacky
 */

#ifndef __ASTAR_MAPCONFIRM_H
#define __ASTAR_MAPCONFIRM_H

#define MaxRoadLines 100
#define START_X    START_X_GRID
#define START_Y    START_Y_GRID
#define END_X      START_X_GRID
#define END_Y      START_Y_GRID
#define EXCEP      0x10


typedef struct RoadLine
{
    unsigned char startx,starty; //单条路径开始内存下标
    unsigned char endx,endy; //单条路径结束下标
    unsigned char RoadAnalysis;
    unsigned char Valid;
    unsigned char owntag;
    /**RoadAnalysis说明
     * bit0,1：单条路径开始点说明 00为不可到达的障碍物 11为可到达的障碍物 01表示为最初起点
     * bit2,3：单条路径结束点说明 00为不可到达的障碍物 11为可到达的障碍物
     * bit4,5：单条路径开始点与结束点之间的可通达区域的状态 00为未验证状态即上位机显示为黄色 11为已验证状态即上位机显示为绿色
     */
    struct RoadLine * parent;
    struct RoadLine * next;
}RoadLine;


class MapRoadLineGrid
{
public:
    unsigned char x;
    unsigned char y;
private:
};



extern unsigned char* StartAddressofFix;
extern RoadLine RoadLines[MaxRoadLines];
extern RoadLine* RoadLineStack;
extern RoadLine* RoadLineStackHeadPtr;
extern unsigned char InitRoadLines(void);
RoadLine* RoadLineMalloc(void);
void RoadLineFree(RoadLine* RoadLinePtr);

unsigned char RoadLinePush(void* lparam,RoadLine* InRoadLinePtr);
unsigned char RoadLinePop(RoadLine* OutRoadLinePtr);
unsigned char RoadLineTop(RoadLine* TopRoadLinePtr);
//unsigned char FindStartindexofRoadLine(unsigned char* StartAddress, unsigned char* xindexptr, unsigned char* yindexptr);
//unsigned char FindEndindexofRoadLine(unsigned char* EndAddress, unsigned char* xindexptr, unsigned char* yindexptr);
unsigned char FindExceptionPoint(void* lparam);
signed char CreateIncrement(unsigned char End, unsigned char Start);
unsigned char CheckClosure(void* lparam,unsigned char End, unsigned char Start, unsigned char Xindex);

#endif /* CODE_USER_ASTAR_MAPCONFIRM_H_ */
