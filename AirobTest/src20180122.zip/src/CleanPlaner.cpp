/*
 * CleanPlaner.cpp
 *
 *  Created on: Jan 17, 2019
 *      Author: Beichen Li
 */

#include "main.h"
#include "CleanPlaner.h"



CleanPlaner::CleanPlaner(void)
{
	BlockStartX = 35;
	BlockStartY = 35;
}
CleanPlaner::~CleanPlaner(void)
{
	;
}

int CleanPlaner::open(MainProgram* lp)
{
    m_MainProgram = lp;
    return 1;
}



void CleanPlaner::SendMapOfOneGrid(int x, int y)
{
    const unsigned char ucMapHead[4] = {0xAA,0xAA,0xF1,0xF1};

    unsigned char* MapSendBuffer = new unsigned char[12];

    int i;

    memcpy(MapSendBuffer,ucMapHead,4);

    MapSendBuffer[4] = x;
    MapSendBuffer[5] = y;
    MapSendBuffer[8] = m_MainProgram->m_MapDealer.Fix[x][y];
    MapSendBuffer[9] = 0;

    for(i = 0; i<12; i++)
    {
        MapSendBuffer[11] ^= MapSendBuffer[i];
    }

    m_MainProgram->m_CommHelper.SendData((char*)MapSendBuffer, 12);
    return;
}

void CleanPlaner::SendNineGrid(int x, int y)
{

	if(0 != m_MainProgram->m_MapDealer.Fix[x-1][y])
	{
		SendMapOfOneGrid(x-1,y);
	}
	if(0 != m_MainProgram->m_MapDealer.Fix[x-1][y+1])
	{
		SendMapOfOneGrid(x-1,y+1);
	}
	if(0 != m_MainProgram->m_MapDealer.Fix[x][y+1])
	{
		SendMapOfOneGrid(x,y+1);
	}
	if(0 != m_MainProgram->m_MapDealer.Fix[x+1][y+1])
	{
		SendMapOfOneGrid(x+1,y+1);
	}
	if(0 != m_MainProgram->m_MapDealer.Fix[x+1][y])
	{
		SendMapOfOneGrid(x+1,y);
	}
	if(0 != m_MainProgram->m_MapDealer.Fix[x+1][y-1])
	{
		SendMapOfOneGrid(x+1,y-1);
	}
	if(0 != m_MainProgram->m_MapDealer.Fix[x][y-1])
	{
		SendMapOfOneGrid(x,y-1);
	}
	if(0 != m_MainProgram->m_MapDealer.Fix[x-1][y-1])
	{
		SendMapOfOneGrid(x-1,y-1);
	}
	return;

}


int CleanPlaner::isBlockClose(int x,int y)
{

	unsigned char left,leftup,up,rightup,right,rightdown,down,leftdown;

	left = m_MainProgram->m_MapDealer.Fix[x-1][y];
	leftup = m_MainProgram->m_MapDealer.Fix[x-1][y+1];
	up = m_MainProgram->m_MapDealer.Fix[x][y+1];
	rightup = m_MainProgram->m_MapDealer.Fix[x+1][y+1];
	right = m_MainProgram->m_MapDealer.Fix[x+1][y];
	rightdown = m_MainProgram->m_MapDealer.Fix[x+1][y-1];
	down = m_MainProgram->m_MapDealer.Fix[x][y-1];
	leftdown = m_MainProgram->m_MapDealer.Fix[x-1][y-1];

	if(left&&leftup&&up&&rightup&&right&&rightdown&&down&&leftdown)
	{
		return 0x01;
	}
	else if(left&&up&&right&&down&&leftup&&leftdown&&rightdown&&(0 == rightup))
	{
		if((up&0x02)&&(right&0x02))
		{
			return 0x02;
		}
		else
		{
			return 0;
		}
	}
	else if(left&&up&&right&&down&&leftup&&leftdown&&rightup&&(~rightdown))
	{
		if((down&0x02) && (right&0x02))
		{
			return 0x03;
		}
		else
		{
			return 0;
		}
	}
	else if(left&&up&&right&&down&&leftup&&rightdown&&rightup&&(~leftdown))
	{
		if((left&0x02) && (down&0x02))
		{
			return 0x04;
		}
		else
		{
			return 0;
		}
	}
	else if(left&&up&&right&&down&&leftdown&&rightdown&&rightup&&(~leftup))
	{
		if((left&0x02) && (up&0x02))
		{
			return 0x05;
		}
		else
		{
			return 0;
		}
	}
	else
	{
		return 0x00;
	}

}


void CleanPlaner::CleanUpdateMap(int x,int y,int value)
{

	char Tempchar[8];

	Tempchar[2] = x;
	Tempchar[3] = y;
	Tempchar[6] = value;

	char *realdata = Tempchar;
    m_MainProgram->m_MapDealer.AddToRevMapDataQueue(realdata, 8);

};


int CleanPlaner::CleanOneBlock(int x,int y)
{
#define THIS_GIRD  0X08
#define COVER      0X01

	static int LastX,LastY;
	int NowX,NowY,State;
	NowX = x;
	NowY = y;


	//unsigned char *map = new unsigned char[MAX_MAP_GRID*MAX_MAP_GRID];

    //m_MainProgram->m_MapDealer.Fix[NowX][NowY] |= THIS_GIRD;
	State |= THIS_GIRD;
	CleanUpdateMap(NowX,NowY,State);

	//memcpy(map,mCleanMap->Fix, MAX_MAP_GRID*MAX_MAP_GRID);

	while(!isBlockClose(NowX,NowY))
	{
		if(0 == m_MainProgram->m_MapDealer.Fix[NowX][NowY-1])
		{
			NowY--;
		}
		else if(0 == m_MainProgram->m_MapDealer.Fix[NowX][NowY+1])
		{
			NowY++;
			//mCleanMap->Fix[NowX][NowY] = CHAGER;
		}
		else if(0 == m_MainProgram->m_MapDealer.Fix[NowX+1][NowY])
		{
			NowX++;
			//mCleanMap->Fix[NowX][NowY] = CHAGER;
		}
		else if(0 == m_MainProgram->m_MapDealer.Fix[NowX-1][NowY])
		{
			NowX--;
			//mCleanMap->Fix[NowX][NowY] = CHAGER;
		}
		else if(0 == m_MainProgram->m_MapDealer.Fix[NowX-1][NowY-1])
		{
			NowX--;
			NowY--;
			//mCleanMap->Fix[NowX][NowY] = CHAGER;
		}
		else if(0 == m_MainProgram->m_MapDealer.Fix[NowX+1][NowY-1])
		{
			NowX++;
			NowY--;
			//mCleanMap->Fix[NowX][NowY] = CHAGER;
		}
		else if(0 == m_MainProgram->m_MapDealer.Fix[NowX-1][NowY+1])
		{
			NowX--;
			NowY++;
			//mCleanMap->Fix[NowX][NowY] = CHAGER;
		}
		else if(0 == m_MainProgram->m_MapDealer.Fix[NowX+1][NowY+1])
		{
			NowX++;
			NowY++;
			//mCleanMap->Fix[NowX][NowY] = CHAGER;
		}


        State = m_MainProgram->m_MapDealer.Fix[NowX][NowY];
        State |= THIS_GIRD;
        CleanUpdateMap(NowX,NowY,State);
		fprintf(stdout, "x: %d y: %d\n", NowX, NowY);

        State = m_MainProgram->m_MapDealer.Fix[LastX][LastY];
        State &= ~THIS_GIRD;
        State |= COVER;
        CleanUpdateMap(LastX,LastY,State);

		SendMapOfOneGrid(LastX,LastY);
		SendNineGrid(LastX,LastY);
		usleep(10000);
        SendMapOfOneGrid(NowX,NowY);
		LastX = NowX;
		LastY = NowY;

	}


	return 0;
}

/*int CleanPlaner::CleanAllRoom()
{

	ret = CleanOneBlock();

}*/































